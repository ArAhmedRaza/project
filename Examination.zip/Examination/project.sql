-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 03, 2020 at 03:11 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `email`, `password`) VALUES
(2, 'admin@admin.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `qid` text NOT NULL,
  `ansid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`qid`, `ansid`) VALUES
('558922117fcef', '5589221195248'),
('55892211e44d5', '55892211f1fa7'),
('5e5e9a5859956', '5e5e9a587fd5c'),
('5e5e9a58bb06c', '5e5e9a58c30cf'),
('5f6504c0259c4', '5f6504c0388fe'),
('5f6504c0a6a29', '5f6504c0b6ce6'),
('5f6504c11dd25', '5f6504c126042'),
('5f6504c171613', '5f6504c183f46'),
('5f6504c1d1ac6', '5f6504c1d99c6'),
('5f6504c223b8e', '5f6504c22b4d3'),
('5f6504c25405b', '5f6504c25ba50'),
('5f6504c2a7447', '5f6504c2aeafe'),
('5f6504c2d4ed2', '5f6504c2dc57c'),
('5f6504c3191ba', '5f6504c32be5e'),
('5f65bdf38ea51', '5f65bdf3b088e'),
('5f65bdf415869', '5f65bdf41fe52');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` text NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `feedback` varchar(500) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `subject`, `feedback`, `date`, `time`) VALUES
('55846be776610', 'testing', 'sunnygkp10@gmail.com', 'testing', 'testing stART', '2015-06-19', '09:22:15pm'),
('5aa40f4636a4e', 'tayyab', 'tayyabali7852@gmail.com', 'asd', 'asdf', '2018-03-10', '05:00:54pm'),
('5e5e9f0458c28', 'AHMED RAZA', 'ahmed1803e@aptechorangi.com', 'Php', 'Amazing Quiz System.', '2020-03-03', '07:16:36pm'),
('5e5f7bce42126', 'Raza', 'ahmed1803e@aptechorangi.com', 'Php:C++', 'WOW.', '2020-03-04', '10:58:38am'),
('5e5f819566e3a', 'Rizwan', 'adnan@gmail.com', 'Pakistan Studies', 'Good Quiz', '2020-03-04', '11:23:17am'),
('5f64f8582012e', 'Raza', 'ahmedraza6106@gmail.com', 'Html', 'Hey Admin.', '2020-09-18', '08:11:36pm'),
('5f65bcfa0a99f', 'AHMED RAZA', 'ahmedraza6106@gmail.com', 'Pakistan', 'Hey Admin', '2020-09-19', '10:10:34am');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `email` varchar(50) NOT NULL,
  `eid` text NOT NULL,
  `score` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`email`, `eid`, `score`, `level`, `sahi`, `wrong`, `date`) VALUES
('ahmedraza6106@gmail.com', '5f6502c8d6a26', 10, 10, 10, 0, '2020-09-18 19:44:46'),
('ahmedraza6106@gmail.com', '5e5e9a03abe94', 2, 2, 2, 0, '2020-09-19 08:07:18');

-- --------------------------------------------------------

--
-- Table structure for table `instruction`
--

CREATE TABLE `instruction` (
  `ID` int(11) NOT NULL,
  `Name` varchar(80) NOT NULL,
  `instruction` text NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `instruction`
--

INSERT INTO `instruction` (`ID`, `Name`, `instruction`, `date`) VALUES
(1, 'Admin', 'Hey Students.', '2020-09-16 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `qid` varchar(50) NOT NULL,
  `option` varchar(5000) NOT NULL,
  `optionid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`qid`, `option`, `optionid`) VALUES
('558922117fcef', 'echo', '5589221195248'),
('558922117fcef', 'print', '558922119525a'),
('558922117fcef', 'printf', '5589221195265'),
('558922117fcef', 'cout', '5589221195270'),
('55892211e44d5', 'int a', '55892211f1f97'),
('55892211e44d5', '$a', '55892211f1fa7'),
('55892211e44d5', 'long int a', '55892211f1fb4'),
('55892211e44d5', 'int a$', '55892211f1fbd'),
('5e5e9a5859956', 'Liaqat ali Khan', '5e5e9a587fd4c'),
('5e5e9a5859956', 'Muhammad Ali Bogra', '5e5e9a587fd59'),
('5e5e9a5859956', 'Muhammad Ali Jinnah', '5e5e9a587fd5c'),
('5e5e9a5859956', 'Allama Iqbal', '5e5e9a587fd5e'),
('5e5e9a58bb06c', 'Quaid e Azam', '5e5e9a58c30bc'),
('5e5e9a58bb06c', 'Ayub Khan', '5e5e9a58c30ca'),
('5e5e9a58bb06c', 'Zulfikar Ali Bhutto', '5e5e9a58c30cd'),
('5e5e9a58bb06c', 'Liaqat ali Khan', '5e5e9a58c30cf'),
('5f6504c0259c4', 'Hyper Text Markup Language', '5f6504c0388fe'),
('5f6504c0259c4', 'High Text Markup Language', '5f6504c03890d'),
('5f6504c0259c4', 'Hyper Tabular Markup Language', '5f6504c038911'),
('5f6504c0259c4', 'None of these', '5f6504c038915'),
('5f6504c0a6a29', '<TD>', '5f6504c0b6cd2'),
('5f6504c0a6a29', '<br>', '5f6504c0b6ce2'),
('5f6504c0a6a29', '<P>', '5f6504c0b6ce6'),
('5f6504c0a6a29', '<TR>', '5f6504c0b6cea'),
('5f6504c11dd25', '<LL>', '5f6504c125f74'),
('5f6504c11dd25', '<DD>', '5f6504c125fcd'),
('5f6504c11dd25', '<DL>', '5f6504c126042'),
('5f6504c11dd25', '<DS>', '5f6504c126047'),
('5f6504c171613', '<head>', '5f6504c183f30'),
('5f6504c171613', '<h6>', '5f6504c183f3e'),
('5f6504c171613', '<heading>', '5f6504c183f42'),
('5f6504c171613', '<h1>', '5f6504c183f46'),
('5f6504c1d1ac6', 'Method', '5f6504c1d99b4'),
('5f6504c1d1ac6', 'Action', '5f6504c1d99c3'),
('5f6504c1d1ac6', 'Both (a)&(b)', '5f6504c1d99c6'),
('5f6504c1d1ac6', 'None of these', '5f6504c1d99c9'),
('5f6504c223b8e', 'How to organise the page', '5f6504c22b4c3'),
('5f6504c223b8e', 'How to display the page', '5f6504c22b4d3'),
('5f6504c223b8e', 'How to display message box on page', '5f6504c22b4d8'),
('5f6504c223b8e', 'None of these', '5f6504c22b4dc'),
('5f6504c25405b', 'Local-server', '5f6504c25ba2e'),
('5f6504c25405b', 'Client-server', '5f6504c25ba50'),
('5f6504c25405b', '3-tier', '5f6504c25ba55'),
('5f6504c25405b', 'None of these', '5f6504c25ba58'),
('5f6504c2a7447', 'No, there is no such terms as Empty Element', '5f6504c2aeaf2'),
('5f6504c2a7447', 'Empty elements are element with no data', '5f6504c2aeafe'),
('5f6504c2a7447', 'No, it is not valid to use Empty Element', '5f6504c2aeb01'),
('5f6504c2a7447', 'None of these', '5f6504c2aeb03'),
('5f6504c2d4ed2', 'size', '5f6504c2dc56c'),
('5f6504c2d4ed2', 'len', '5f6504c2dc579'),
('5f6504c2d4ed2', 'maxlength', '5f6504c2dc57c'),
('5f6504c2d4ed2', 'all of these', '5f6504c2dc57e'),
('5f6504c3191ba', '<Body>', '5f6504c32be4e'),
('5f6504c3191ba', '<Title>', '5f6504c32be5b'),
('5f6504c3191ba', '<HTML>', '5f6504c32be5e'),
('5f6504c3191ba', '<Form>', '5f6504c32be60'),
('5f65bdf38ea51', 'Client Side', '5f65bdf3b088e'),
('5f65bdf38ea51', 'Serverside', '5f65bdf3b089e'),
('5f65bdf38ea51', 'Open Source', '5f65bdf3b08a2'),
('5f65bdf38ea51', 'none', '5f65bdf3b08a6'),
('5f65bdf415869', 'Java', '5f65bdf41fe52'),
('5f65bdf415869', 'Php', '5f65bdf41fe60'),
('5f65bdf415869', 'C#', '5f65bdf41fe65'),
('5f65bdf415869', 'Laraval', '5f65bdf41fe69');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `eid` text NOT NULL,
  `qid` text NOT NULL,
  `qns` text NOT NULL,
  `choice` int(10) NOT NULL,
  `sn` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`eid`, `qid`, `qns`, `choice`, `sn`) VALUES
('558921841f1ec', '558922117fcef', 'what is command for print in php??', 4, 1),
('558921841f1ec', '55892211e44d5', 'which is a variable of php??', 4, 2),
('5e5e9a03abe94', '5e5e9a5859956', 'Pakistan First President name is ?', 4, 1),
('5e5e9a03abe94', '5e5e9a58bb06c', 'First Prime Minister Of Pakistan.', 4, 2),
('5f6502c8d6a26', '5f6504c0259c4', 'HTML stands for?', 4, 1),
('5f6502c8d6a26', '5f6504c0a6a29', 'which of the following tag is used to mark a begining of paragraph ?\r\n', 4, 2),
('5f6502c8d6a26', '5f6504c11dd25', 'From which tag descriptive list starts ?', 4, 3),
('5f6502c8d6a26', '5f6504c171613', 'Correct HTML tag for the largest heading is', 4, 4),
('5f6502c8d6a26', '5f6504c1d1ac6', ' The attribute of <form> tag', 4, 5),
('5f6502c8d6a26', '5f6504c223b8e', 'Markup tags tell the web browser', 4, 6),
('5f6502c8d6a26', '5f6504c25405b', ' www is based on which model?', 4, 7),
('5f6502c8d6a26', '5f6504c2a7447', 'What are Empty elements and is it valid?', 4, 8),
('5f6502c8d6a26', '5f6504c2d4ed2', ' Which of the following attributes of text box control allow to limit the maximum character?', 4, 9),
('5f6502c8d6a26', '5f6504c3191ba', 'Web pages starts with which ofthe following tag?', 4, 10),
('5f65bd9c6eb7e', '5f65bdf38ea51', 'Javascript is _', 4, 1),
('5f65bd9c6eb7e', '5f65bdf415869', 'Javascript is framework', 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `eid` text NOT NULL,
  `title` varchar(100) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `time` bigint(20) NOT NULL,
  `intro` text NOT NULL,
  `tag` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`eid`, `title`, `sahi`, `wrong`, `total`, `time`, `intro`, `tag`, `date`) VALUES
('558921841f1ec', 'Php Coding', 2, 1, 2, 5, '', 'PHP', '2015-06-23 09:06:12'),
('5e5e9a03abe94', 'History', 1, 1, 2, 4, '', '#History', '2020-03-03 17:55:15'),
('5f6502c8d6a26', 'Html', 1, 1, 10, 4, 'Html Mcqs', '#Html', '2020-09-18 18:56:08'),
('5f65bd9c6eb7e', 'Javascript', 1, 1, 2, 2, 'None.', '#java', '2020-09-19 08:13:16');

-- --------------------------------------------------------

--
-- Table structure for table `rank`
--

CREATE TABLE `rank` (
  `email` varchar(50) NOT NULL,
  `score` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rank`
--

INSERT INTO `rank` (`email`, `score`, `time`) VALUES
('ahmedraza6106@gmail.com', 20, '2020-09-19 08:19:58');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(50) NOT NULL,
  `gender` varchar(5) NOT NULL,
  `college` varchar(100) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `mob` bigint(20) DEFAULT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `gender`, `college`, `email`, `mob`, `password`) VALUES
('Raza', 'M', '', 'ahmed.raza9531@gmail.com', 0, '744cac2f72716c8a1ce6000f79fe36b1'),
('RAZA', 'M', 'The Aptech', 'ahmedraza6106@gmail.com', 31200000, '744cac2f72716c8a1ce6000f79fe36b1'),
('User', 'M', '', 'user@user.com', 0, 'ee11cbb19052e40b07aac0ca060c23ee');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `instruction`
--
ALTER TABLE `instruction`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `instruction`
--
ALTER TABLE `instruction`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
