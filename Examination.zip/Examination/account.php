<!DOCTYPE html>
<html lang="en">


<!-- index.html  21 Nov 2019 03:44:50 GMT -->
<head runat="server">
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title>Examination</title>
  <!-- General CSS Files -->
  <link rel="stylesheet" href="assets/css/app.min.css">
  <!-- Template CSS -->
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="assets/css/components.css">
  <!-- Custom style CSS -->
  <link rel="stylesheet" href="assets/css/custom.css">
  <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.ico' />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 <!--alert message-->
<?php if(@$_GET['w'])
{echo'<script>alert("'.@$_GET['w'].'");</script>';}
?>
<!--alert message end-->

</head>
<?php
include_once 'dbConnection.php';
?>
<body onload="f1()">
 <?php
 include_once 'dbConnection.php';
session_start();
if( empty( $_SESSION['quiz'] ) )$_SESSION['quiz']=date('Y-m-d H:i:s');
  if(!(isset($_SESSION['email']))){
header("location:index.php");

}
else
{
$name = $_SESSION['name'];
$email=$_SESSION['email'];

include_once 'dbConnection.php';
}
?>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
      <nav class="navbar navbar-expand-lg main-navbar sticky">
        <div class="form-inline mr-auto">
          <ul class="navbar-nav mr-3">
            <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg
									collapse-btn"> <i data-feather="align-justify"></i></a></li>
            <li><a href="#" class="nav-link nav-link-lg fullscreen-btn">
                <i data-feather="maximize"></i>
              </a></li>
            <li>
<!--              <form class="form-inline mr-auto">
                <div class="search-element">
                  <input class="form-control" type="search" placeholder="Search" aria-label="Search" data-width="200">
                  <button class="btn" type="submit">
                    <i class="fas fa-search"></i>
                  </button>
                </div>
              </form>-->
            </li>
          </ul>
        </div>
        <ul class="navbar-nav navbar-right">
          <li class="dropdown dropdown-list-toggle"><a href="#" data-toggle="dropdown"
              class="nav-link nav-link-lg message-toggle"><i data-feather="mail"></i>
              <span class="badge headerBadge1">
			  <?php $result = mysqli_query($con,"SELECT * FROM instruction") or die('Error');
			  $res = mysqli_num_rows($result);
			  ?>
                <?php echo $res ;?> </span> </a>
            <div class="dropdown-menu dropdown-list dropdown-menu-right pullDown">
              <div class="dropdown-header">
                Messages
                <div class="float-right">
                  <a href="#">Mark All As Read</a>
                </div>
              </div>
              <div class="dropdown-list-content dropdown-list-message">
			   <?php $result = mysqli_query($con,"SELECT * FROM instruction") or die('Error');
while($row = mysqli_fetch_array($result)) {
	$uname = $row['Name'];
	$instruction = $row['instruction'];
	$date= $row['date'];
		?>
                <a href="#" class="dropdown-item">
				<span class="dropdown-item-avatar
											text-white"> 
											<img alt="image" src="assets/img/admin.png" class="rounded-circle">
                  </span> <span class="dropdown-item-desc"> <span class="message-user"><?php echo $uname;?></span>
                    <span class="time messege-text"><?php echo $instruction;?></span>
                    <span class="time"><?php echo $date;?></span>
                  </span>
                </a>
				<?php }?>
              </div>
              <div class="dropdown-footer text-center">
                <a href="#">View All <i class="fas fa-chevron-right"></i></a>
              </div>
            </div>
          </li>
          <li class="dropdown dropdown-list-toggle"><a href="#" data-toggle="dropdown"
              class="nav-link notification-toggle nav-link-lg"><i data-feather="bell" class="bell"></i>
            </a>
            <div class="dropdown-menu dropdown-list dropdown-menu-right pullDown">
              <div class="dropdown-header">
                Notifications
                <div class="float-right">
                  <a href="#">Mark All As Read</a>
                </div>
              </div>
              <div class="dropdown-list-content dropdown-list-icons">
                <a href="#" class="dropdown-item dropdown-item-unread"> <span
                    class="dropdown-item-icon bg-success text-white"> <i class="fas fa-check"></i>
                  </span> <span class="dropdown-item-desc"> <?php echo $name; ?> You Are Login Now. <div class="badges">
                      <span class="badge badge-success">Online</span>
                    </div><span class="time" id="time"><script>
					  var f = new Date();
            document.getElementById("time").innerHTML = "Your Login at " + f.getHours() + ":" + f.getMinutes();
					  </script></span>
                  </span>
                </a>
              </div>
              <div class="dropdown-footer text-center">
                <a href="#">View All <i class="fas fa-chevron-right"></i></a>
              </div>
            </div>
          </li>
          <li class="dropdown"><a href="#" data-toggle="dropdown"
              class="nav-link dropdown-toggle nav-link-lg nav-link-user"> <img alt="image" src="assets/img/user.png"
                class="user-img-radious-style"> <span class="d-sm-none d-lg-inline-block"></span></a>
            <div class="dropdown-menu dropdown-menu-right pullDown">
              <div class="dropdown-title"><?php echo $name;?></div>
			  <a href="account.php?q=5" class="dropdown-item has-icon"> <i class="far
										fa-user"></i> Profile
              </a>
              <div class="dropdown-divider"></div>
              <a href="logout.php?q=account.php" class="dropdown-item has-icon text-danger"> <i class="fas fa-sign-out-alt"></i>
                Logout
              </a>
            </div>
          </li>
        </ul>
      </nav>
      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <div class="sidebar-brand">
            <a href="account.php?q=1"> <img alt="image" src="assets/img/logo.png" class="header-logo" /> <span
                class="logo-name">Exam</span>
            </a>
          </div>
          <ul class="sidebar-menu">
            <li class="menu-header">Main</li>
            <li class="dropdown">
              <a href="account.php?q=1" class="nav-link" <?php if(@$_GET['q']==1) echo 'class="active"';?>><i data-feather="monitor"></i><span>Dashboard</span></a>
            </li>
            <li class="dropdown">
              <a href="account.php?q=2" class="nav-link" <?php if(@$_GET['q']==2) echo 'class="active"';?>><i
                  data-feather="briefcase"></i><span>History</span></a>
            </li>
            <li><a class="nav-link" href="account.php?q=3" <?php if(@$_GET['q']==3) echo 'class="active"';?>><i data-feather="sliders"></i><span>Ranking</span></a></li>
			<li class="dropdown <?php if(@$_GET['q']==4) echo'class="active"'; ?>">
              <a href="account.php?q=4" class="nav-link"><i data-feather="mail"></i><span>Feedback</span></a>
            </li>
           <li class="dropdown">
              <a href="account.php?q=5" class="nav-link <?php if(@$_GET['q']==5) echo'class="active"'; ?>" ><i
                  data-feather="user-check"></i><span>Profile</span></a>
            </li>
			<!--<li class="dropdown">
              <a href="" class="nav-link"><i data-feather="command"></i><span>Chat</span></a>
            </li>-->
        </aside>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
        	<?php if(@$_GET['q']==1) {

$result = mysqli_query($con,"SELECT * FROM quiz ORDER BY date DESC") or die('Error');
$c=1;
while($row = mysqli_fetch_array($result)) {
	$title = $row['title'];
	$total = $row['total'];
	$sahi = $row['sahi'];
    $time = $row['time'];
	$eid = $row['eid'];
$q12=mysqli_query($con,"SELECT score FROM history WHERE eid='$eid' AND email='$email'" )or die('Error98');
$rowcount=mysqli_num_rows($q12);	
if($rowcount == 0){
	?>
         <?php echo'
          <div class="row ">
            <div class="col-12 col-sm-12 col-lg-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Exam Of</h5>
                          <h2 class="mb-3 font-18">'.$title.'</h2>
                          <p class="mb-0"><a href="account.php?q=quiz&step=2&eid='.$eid.'&n=1&t='.$total.'"><span class="col-green">Click</span></a> and Play.</p>
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/3.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>';
		  ?>
         
		  <?php }
else
{
	?>
	       <?php echo'          <div class="row ">
            <div class="col-12 col-sm-12 col-lg-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Exam Of</h5>
                          <h2 class="mb-3 font-18">'.$title.'</h2>
                          <p class="mb-0"><a href="update.php?q=quizre&step=25&eid='.$eid.'&n=1&t='.$total.'"><span class="col-red">Click</span></a> and Restart.</p>
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/3.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>';
		  ?>
		  	<?php
}
}
$c=0;

}?>
		  <!--quiz start-->
<?php

if(@$_GET['q']== 'quiz' && @$_GET['step']== 2) {
	
$eid=@$_GET['eid'];
$sn=@$_GET['n'];
$total=@$_GET['t'];
$q=mysqli_query($con,"SELECT * FROM questions WHERE eid='$eid' AND sn='$sn' " );
$qt=mysqli_query($con,"SELECT * FROM quiz WHERE eid='$eid'" );
while($row = mysqli_fetch_array($qt))
{
	$time = $row['time'];
}
$sec = 60;
$ti=$time*60;
?>
		<div id ="res" class="d-none">
<?php  echo $ti;?>
</div>

<script language ="javascript" >
    <?php
              $start=$_SESSION['quiz'];
              $end=date('Y-m-d H:i:s', strtotime( $_SESSION['quiz'] . ' +20 minutes' ) );
                echo "
                    var date_quiz_start='$start';
                    var date_quiz_end='$end';
                    var time_quiz_end=new Date('$end').getTime();";
      ?>
	  
        var tim;
        var hour= 00;
        var min = 01;
        //var sec = 60;
		 var sec = document.getElementById("res").innerHTML;
		
        var f = new Date();
        function f1() {
            f2();
            document.getElementById("starttime").innerHTML = "Your started your Exam at " + f.getHours() + ":" + f.getMinutes();
        }
        function f2() {
            if (parseInt(sec) > 0) {
                sec = parseInt(sec) - 1;
                document.getElementById("showtime").innerHTML = "Your Left Time  is : " + sec+" Seconds";
                tim = setTimeout("f2()", 1000);
            }
            else {
                if (parseInt(sec) == 0) {
                    min = parseInt(min) - 1;
                    if (parseInt(min) == 0) {
                        clearTimeout(tim);
						alert("Time Over");
                        location.href ="account.php?q=1";
                    }
                    else {
                        sec = 60;
                        document.getElementById("showtime").innerHTML = "Your Left Time  is :" + min + " Minutes ," + sec + " Seconds";
                        tim = setTimeout("f2()", 1000);
                    }
                }
            }
        }
    </script>
				 <form id="form1" runat="server">
    <div>
      <div class="card card-info">
  <div class="card-body">
    <div id="starttime"></div>

            <div id="endtime"></div>
            <div id="showtime"></div>
  </div>
</div>   
    </div>
    </form>
	<?php
echo '<div class="card card-info">';
while($row=mysqli_fetch_array($q) )
{
$qns=$row['qns'];
$qid=$row['qid'];
echo '<div class="card-header">
                    <h4><b>Question &nbsp;'.$sn.'&nbsp;::<br />'.htmlspecialchars($qns).'</b><br /><br /></h4>
                  </div>';
}
$q=mysqli_query($con,"SELECT * FROM options where qid = '$qid'");
echo '<form action="update.php?q=quiz&step=2&eid='.$eid.'&n='.$sn.'&t='.$total.'&qid='.$qid.'" method="POST"  class="form-horizontal">';

while($row=mysqli_fetch_array($q) )
{
$option=$row['option'];
$optionid=$row['optionid'];
echo'<div class="card-body">
<input type="radio" name="ans" value="'.$optionid.'" required="required"> '.htmlspecialchars($option).'
                  </div>
';
}
echo'<div class="card-footer text-right">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
</form></div>';
//header("location:dash.php?q=4&step=2&eid=$id&n=$total");
}
//result display
//result display
if(@$_GET['q']== 'result' && @$_GET['eid']) 
{
$eid=@$_GET['eid'];
$q=mysqli_query($con,"SELECT * FROM history WHERE eid='$eid' AND email='$email' " )or die('Error157');
echo  '<div class="card">
                  <div class="card-header">
                    <h4>Result</h4>
                  </div>
                  <div class="card-body">
                    <table class="table">';

while($row=mysqli_fetch_array($q) )
{
$s=$row['score'];
$w=$row['wrong'];
$r=$row['sahi'];
$qa=$row['level'];
echo '<thead>
                        <tr>
                          <th scope="col">Name</th>
                          <th scope="col">Total Question</th>
                          <th scope="col">Rigth Answers</th>
                          <th scope="col">Wrong Answers</th>
						  <th scope="col">Number</th>
                        </tr>
                      </thead>
					  <tbody>
                        <tr>
                          <th scope="row">'.$name.'</th>
                          <td>'.$qa.'</td>
                          <td>'.$r.'</td>
                          <td>'.$w.'</td>
						  <td>'.$s.'</td>
                        </tr>
                      </tbody>
                    ';
}
$q=mysqli_query($con,"SELECT * FROM rank WHERE  email='$email' " )or die('Error157');
while($row=mysqli_fetch_array($q) )
{
$s=$row['score'];
echo '<thead><tr>
<th scope="col">Overall score</th>

</thead>
</tr>
<tr>
<tbody>
<td>'.$s.'</td>
</tr>
<tbody>';
}
echo '</table>
<div class="card-footer text-right">
        <a href="account.php?q=1"><button type="button" class="btn btn-primary">Back</button></a>
                  </div>
      </div>
      </div>';

}
?>

<!--quiz end-->
<!--quiz end-->
<?php
//history start
if(@$_GET['q']== 2) 
{
$q=mysqli_query($con,"SELECT * FROM history WHERE email='$email' ORDER BY date DESC")or die('Error197');
echo  '<div class="card">
<div class="card-header">
                    <h4>History</h4>
                  </div>
				  <div class="card-body">
<table class="table" >
<thead>
    <tr">
      <th scope="col">S.N.</th>
      <th scope="col">Exam</th>
      <th scope="col">Question Solved</th>
      <th scope="col">Right</th>
	  <th scope="col">Wrong</th>
	  <th scope="col">Score</th>
    </tr>
  </thead>';
$c=0;
while($row=mysqli_fetch_array($q) )
{
$eid=$row['eid'];
$s=$row['score'];
$w=$row['wrong'];
$r=$row['sahi'];
$qa=$row['level'];
$q23=mysqli_query($con,"SELECT title FROM quiz WHERE  eid='$eid'" )or die('Error208');
while($row=mysqli_fetch_array($q23) )
{
$title=$row['title'];
}
$c++;
echo '
<tbody>
<tr>
      <th scope="row">'.$c.'</th>
      <td>'.$title.'</td>
      <td>'.$qa.'</td>
	  <td>'.$r.'</td>
      <td>'.$w.'</td>
	  <td>'.$s.'</td>
    </tr>
	<tbody>';
}
echo'</table></div>
<div class="card-footer text-right">
        <a href="account.php?q=1"><button type="button" class="btn btn-primary">Back</button></a>
                  </div></div>'; }
//ranking start
if(@$_GET['q']== 3) 
{
$q=mysqli_query($con,"SELECT * FROM rank  ORDER BY score DESC " )or die('Error223');
echo  '<div class="card">
<div class="card-header">
<h4>Ranking</h4>
</div>
<div class="card-body">
<table class="table" >
<thead>
    <tr">
      <th scope="col">Rank</th>
      <th scope="col">Name</th>
      <th scope="col">Gender</th>
	  <th scope="col">Score</th>
    </tr>
  </thead>';
$c=0;
while($row=mysqli_fetch_array($q) )
{
$e=$row['email'];
$s=$row['score'];
$q12=mysqli_query($con,"SELECT * FROM user WHERE email='$e'" )or die('Error231');
while($row=mysqli_fetch_array($q12) )
{
$name=$row['name'];
$gender=$row['gender'];
$college=$row['college'];
}
$c++;
echo '
<tbody>
 <tr>
      <th scope="row">'.$c.'</th>
      <td>'.$name.'</td>
      <td>'.$gender.'</td>
      <td>'.$s.'</td>
    </tr>
	</tbody>';
}
echo '</div></table></div>
<div class="card-footer text-right">
        <a href="account.php?q=1"><button type="button" class="btn btn-primary">Back</button></a>
                  </div></div>';
}
?>
<?php
if(@$_GET['q']== 4) {
	if(isset($_POST['feedsend']))
{
$name = $_POST['name'];
$email = $_POST['email'];
$subject = $_POST['subject'];
$id=uniqid();
$date=date("Y-m-d");
$time=date("h:i:sa");
$feedback = $_POST['feedback'];
$res=mysqli_query($con,"INSERT INTO feedback VALUES  ('$id' , '$name', '$email' , '$subject', '$feedback' , '$date' , '$time')")or die ("Error");
	if($res>0)
	{
		echo '<div class="alert alert-success alert-dismissible show fade">
                      <div class="alert-body">
                        <button class="close" data-dismiss="alert">
                          <span>&times;</span>
                        </button>
                        Send Successfully...
                      </div>
                    </div>';
	}
  else{
			echo '<div class="alert alert-danger alert-dismissible show fade">
                      <div class="alert-body">
                        <button class="close" data-dismiss="alert">
                          <span>&times;</span>
                        </button>
                        Sending Error...
                      </div>
                    </div>';
	}
}
	$q=mysqli_query($con,"select * from user where email='$email'");
	while($row = mysqli_fetch_array($q))
	{
	$name=$row['name'];
	$email=$row['email'];
		echo'
  <div class="col-12 col-sm-12 col-lg-12">
                <div class="card">
			
                  <form method="post" action="">
                    <div class="card-header">
                      <h4>Feedback</h4>
                    </div>
                    <div class="card-body">
                      <div class="form-group">
                        <label>Your Name</label>
                        <input type="text" name="name" class="form-control" value="'.$name.'" required="Name">
                      </div>
					  <div class="form-group">
                        <label>Subject</label>
                        <input type="text" name="subject" class="form-control" required="Subject">
                      </div>
                      <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" class="form-control" value="'.$email.'" required="Email">
                      </div>
                      <div class="form-group mb-0">
                        <label>Message</label>
                        <textarea name="feedback" class="form-control" required=""></textarea>
                      </div>
                    </div>
                    <div class="card-footer text-right">
                      <button class="btn btn-primary" name="feedsend">Send...</button>
                    </div>
                  </form>
                </div>
              </div>
				  ';
} 
}?>
<?php
if(@$_GET['q']==5){
	if(isset($_POST['sub']))
{
$name = $_POST['name'];
$password = md5($_POST['password']);
$res=mysqli_query($con,"update user set name='$name', password='$password' WHERE email='$email'" );
	if($res>0)
	{
		echo '<div class="alert alert-success alert-dismissible show fade">
                      <div class="alert-body">
                        <button class="close" data-dismiss="alert">
                          <span>&times;</span>
                        </button>
                        Update Successfully...
                      </div>
                    </div>';
	}
  else{
			echo '<div class="alert alert-danger alert-dismissible show fade">
                      <div class="alert-body">
                        <button class="close" data-dismiss="alert">
                          <span>&times;</span>
                        </button>
                        Updating Error...
                      </div>
                    </div>';
	}
}
	$q=mysqli_query($con,"select * from user where email='$email'");
	while($row = mysqli_fetch_array($q))
	{
	$name=$row['name'];
	$email=$row['email'];
	$password=$row['password'];
		echo'
  <div class="col-12 col-sm-12 col-lg-12">
                <div class="card">
                  <form method="post" action="">
                    <div class="card-header">
                      <h4>Profile</h4>
                    </div>
                    <div class="card-body">
                      <div class="form-group">
                        <label>Your Name</label>
                        <input type="text" name="name" class="form-control" value="'.$name.'" required="Name">
                      </div>
					  <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" class="form-control" value="'.$email.'" required="Email" disabled>
                      </div>
                      <div class="form-group">
                        <label>Password</label>
                        <input type="text" name="password" class="form-control" required="Password">
                      </div>
                    </div>
                    <div class="card-footer text-right">
                      <button class="btn btn-primary" name="sub">Save Changes</button>
                    </div>
                  </form>
                </div>
              </div>
				  ';
}

}

?>

      </section>
        <div class="settingSidebar">
          <a href="javascript:void(0)" class="settingPanelToggle"> <i class="fa fa-spin fa-cog"></i>
          </a>
          <div class="settingSidebar-body ps-container ps-theme-default">
            <div class=" fade show active">
              <div class="setting-panel-header">Setting Panel
              </div>
              <div class="p-15 border-bottom">
                <h6 class="font-medium m-b-10">Select Layout</h6>
                <div class="selectgroup layout-color w-50">
                  <label class="selectgroup-item">
                    <input type="radio" name="value" value="1" class="selectgroup-input-radio select-layout" checked>
                    <span class="selectgroup-button">Light</span>
                  </label>
                  <label class="selectgroup-item">
                    <input type="radio" name="value" value="2" class="selectgroup-input-radio select-layout">
                    <span class="selectgroup-button">Dark</span>
                  </label>
                </div>
              </div>
              <div class="p-15 border-bottom">
                <h6 class="font-medium m-b-10">Sidebar Color</h6>
                <div class="selectgroup selectgroup-pills sidebar-color">
                  <label class="selectgroup-item">
                    <input type="radio" name="icon-input" value="1" class="selectgroup-input select-sidebar">
                    <span class="selectgroup-button selectgroup-button-icon" data-toggle="tooltip"
                      data-original-title="Light Sidebar"><i class="fas fa-sun"></i></span>
                  </label>
                  <label class="selectgroup-item">
                    <input type="radio" name="icon-input" value="2" class="selectgroup-input select-sidebar" checked>
                    <span class="selectgroup-button selectgroup-button-icon" data-toggle="tooltip"
                      data-original-title="Dark Sidebar"><i class="fas fa-moon"></i></span>
                  </label>
                </div>
              </div>
              <div class="p-15 border-bottom">
                <h6 class="font-medium m-b-10">Color Theme</h6>
                <div class="theme-setting-options">
                  <ul class="choose-theme list-unstyled mb-0">
                    <li title="white" class="active">
                      <div class="white"></div>
                    </li>
                    <li title="cyan">
                      <div class="cyan"></div>
                    </li>
                    <li title="black">
                      <div class="black"></div>
                    </li>
                    <li title="purple">
                      <div class="purple"></div>
                    </li>
                    <li title="orange">
                      <div class="orange"></div>
                    </li>
                    <li title="green">
                      <div class="green"></div>
                    </li>
                    <li title="red">
                      <div class="red"></div>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="p-15 border-bottom">
                <div class="theme-setting-options">
                  <label class="m-b-0">
                    <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input"
                      id="mini_sidebar_setting">
                    <span class="custom-switch-indicator"></span>
                    <span class="control-label p-l-10">Mini Sidebar</span>
                  </label>
                </div>
              </div>
              <div class="p-15 border-bottom">
                <div class="theme-setting-options">
                  <label class="m-b-0">
                    <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input"
                      id="sticky_header_setting">
                    <span class="custom-switch-indicator"></span>
                    <span class="control-label p-l-10">Sticky Header</span>
                  </label>
                </div>
              </div>
              <div class="mt-4 mb-4 p-3 align-center rt-sidebar-last-ele">
                <a href="#" class="btn btn-icon icon-left btn-primary btn-restore-theme">
                  <i class="fas fa-undo"></i> Restore Default
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <footer class="main-footer">
        <div class="footer-left">
          Developed By AHMED RAZA
        </div>
        <div class="footer-right">
        </div>
      </footer>
    </div>
  </div>
  <!-- General JS Scripts -->
  <script src="assets/js/app.min.js"></script>
  <!-- JS Libraies -->
  <script src="assets/bundles/apexcharts/apexcharts.min.js"></script>
  <!-- Page Specific JS File -->
  <script src="assets/js/page/index.js"></script>
  <!-- Template JS File -->
  <script src="assets/js/scripts.js"></script>
  <!-- Custom JS File -->
  <script src="assets/js/custom.js"></script>
    <script src="assets/bundles/sweetalert/sweetalert.min.js"></script>
  <!-- Page Specific JS File -->
  <script src="assets/js/page/sweetalert.js"></script>
</body>
<!-- index.html  21 Nov 2019 03:47:04 GMT -->
</html>