<?php
//all the variables defined here are accessible in all the files that include this one
$con= mysqli_connect('localhost','root','','project')or die("Could not connect to mysql".mysqli_error());

?>