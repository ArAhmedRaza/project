<!DOCTYPE html>
<html lang="en">


<!-- index.html  21 Nov 2019 03:44:50 GMT -->
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title>Exam || Admin Panel</title>
  <!-- General CSS Files -->
  <!-- General CSS Files -->
  <link rel="stylesheet" href="assets/css/app.min.css">
  <!-- Template CSS -->
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="assets/css/components.css">
  <!-- Custom style CSS -->
  <link rel="stylesheet" href="assets/css/custom.css">
    <link rel="stylesheet" href="assets/bundles/datatables/datatables.min.css">
  <link rel="stylesheet" href="assets/bundles/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <link rel='shortcut icon' type='image/x-icon' href='assets/img/favicon.ico' />
</head>

<body>
<?php
 include_once 'dbConnection.php';
session_start();
$email=$_SESSION['email'];
  if(!(isset($_SESSION['email']))){
header("location:admin_login.php");

}
else
{
$name = $_SESSION['name'];;

include_once '../Database/dbConnection.php';
}?>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
      <nav class="navbar navbar-expand-lg main-navbar sticky">
        <div class="form-inline mr-auto">
          <ul class="navbar-nav mr-3">
            <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg
									collapse-btn"> <i data-feather="align-justify"></i></a></li>
            <li><a href="#" class="nav-link nav-link-lg fullscreen-btn">
                <i data-feather="maximize"></i>
              </a></li>
            <li>
          <!--    <form class="form-inline mr-auto">
                <div class="search-element">
                  <input class="form-control" type="search" placeholder="Search" aria-label="Search" data-width="200">
                  <button class="btn" type="submit">
                    <i class="fas fa-search"></i>
                  </button>
                </div>
              </form>-->
            </li>
          </ul>
        </div>
        <ul class="navbar-nav navbar-right">
          <li class="dropdown dropdown-list-toggle"><a href="#" data-toggle="dropdown"
              class="nav-link nav-link-lg message-toggle"><i data-feather="mail"></i>
              <span class="badge headerBadge1">
			  <?php $result = mysqli_query($con,"SELECT * FROM feedback") or die('Error');
			  $res = mysqli_num_rows($result);
			  ?>
                <?php echo $res ;?> </span> </a>
            <div class="dropdown-menu dropdown-list dropdown-menu-right pullDown">
			
              <div class="dropdown-header">
                Messages
                <div class="float-right">
                  <a href="#">Mark All As Read</a>
                </div>
              </div>
			  
              <div class="dropdown-list-content dropdown-list-message">  
			  <?php $result = mysqli_query($con,"SELECT * FROM feedback") or die('Error');
while($row = mysqli_fetch_array($result)) {
	$uname = $row['name'];
	$date = $row['date'];
	$date= date("d-m-Y",strtotime($date));
	$feedback = $row['feedback'];
		?>
                <a href="#" class="dropdown-item">
				<span class="dropdown-item-avatar
											text-white"> 
											<img alt="image" src="assets/img/user.png" class="rounded-circle">
                  </span> <span class="dropdown-item-desc"> <span class="message-user"><?php echo $uname;?></span>
                    <span class="time messege-text"><?php echo $feedback;?></span>
                    <span class="time"><?php echo $date;?></span>
                  </span>
                </a>
				<?php }?>
              </div>

              <div class="dropdown-footer text-center">
                <a href="dash.php?q=3">View All <i class="fas fa-chevron-right"></i></a>
              </div>
            </div>
          </li>

          <li class="dropdown dropdown-list-toggle"><a href="#" data-toggle="dropdown"
              class="nav-link notification-toggle nav-link-lg"><i data-feather="bell" class="bell"></i>
            </a>
            <div class="dropdown-menu dropdown-list dropdown-menu-right pullDown">
              <div class="dropdown-header">
                Notifications
                <div class="float-right">
                  <a href="#">Mark All As Read</a>
                </div>
              </div>
              <div class="dropdown-list-content dropdown-list-icons">
                <a href="#" class="dropdown-item dropdown-item-unread"> <span
                    class="dropdown-item-icon bg-success text-white"> <i class="fas fa-check"></i>
                  </span> <span class="dropdown-item-desc"> <?php echo $name; ?> You Are Login Now. <div class="badges">
                      <span class="badge badge-success">Online</span>
                    </div><span class="time" id="time"><script>
					  var f = new Date();
            document.getElementById("time").innerHTML = "Your Login at " + f.getHours() + ":" + f.getMinutes();
					  </script></span>
                  </span>
                </a>
              </div>
              <div class="dropdown-footer text-center">
                <a href="#">View All <i class="fas fa-chevron-right"></i></a>
              </div>
            </div>
          </li>
          <li class="dropdown"><a href="#" data-toggle="dropdown"
              class="nav-link dropdown-toggle nav-link-lg nav-link-user"> <img alt="image" src="assets/img/admin.png"
                class="user-img-radious-style"> <span class="d-sm-none d-lg-inline-block"></span></a>
            <div class="dropdown-menu dropdown-menu-right pullDown">
              <div class="dropdown-title"><?php echo $name;?></div>
              <div class="dropdown-divider"></div>
              <a href="logout.php?q=dash.php" class="dropdown-item has-icon text-danger"> <i class="fas fa-sign-out-alt"></i>
                Logout
              </a>
            </div>
          </li>
        </ul>
      </nav>
      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <div class="sidebar-brand">
            <a href="dash.php?q=0"> <img alt="image" src="assets/img/logo.png" class="header-logo" /> <span
                class="logo-name">Exam</span>
            </a>
          </div>
          <ul class="sidebar-menu">
            <li class="menu-header">Main</li>
            <li class="dropdown<?php if(@$_GET['q']==0) echo'class="active"'; ?>">
              <a href="dash.php?q=0" class="nav-link"><i data-feather="monitor"></i><span>Dashboard</span></a>
            </li>
            <li class="dropdown<?php if(@$_GET['q']==3) echo'class="active"'; ?>">
              <a href="dash.php?q=3" class="nav-link"><i data-feather="mail"></i><span>Feedback</span></a>
            </li>
            <li class="dropdown<?php if(@$_GET['q']==4) echo'class="active"'; ?>">
              <a href="dash.php?q=4" class="nav-link"><i data-feather="copy"></i><span>Add Quiz</span></a>
            </li>
            <li class="dropdown<?php if(@$_GET['q']==5) echo'class="active"'; ?>">
			<a class="nav-link " href="dash.php?q=5"><i data-feather="file"></i><span>Remove Quiz</span></a>
			</li>
			<li class="dropdown"<?php if(@$_GET['q']==6) echo 'class="active"';?>>
              <a href="dash.php?q=6" class="nav-link"><i
                  data-feather="briefcase"></i><span>Check Exam</span></a>
            </li>
            <li class="dropdown<?php if(@$_GET['q']==2) echo'class="active"'; ?>">
			<a class="nav-link" href="dash.php?q=2"><i data-feather="sliders"></i><span>Ranking</span></a>
			</li>
            <li class="dropdown<?php if(@$_GET['q']==1) echo'class="active"'; ?>">
              <a href="dash.php?q=1" class="nav-link"><i
                  data-feather="user-check"></i><span>Users</span></a>
            </li>
			<li class="dropdown">
              <a href="" class="menu-toggle nav-link has-dropdown"><i data-feather="command"></i><span>Instruction</span></a>
			  <ul class="dropdown-menu">
                <li><a class="nav-link <?php if(@$_GET['q']==7) echo'class="active"'; ?>" href="dash.php?q=7">Add Instruction</a></li>
                <li><a class="nav-link <?php if(@$_GET['q']==8) echo'class="active"'; ?>" href="dash.php?q=8">Read & Delete Instruction</a></li>
              </ul>
            </li>
        </aside>
      </div>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
<?php if(@$_GET['q']==0) {

$result = mysqli_query($con,"SELECT * FROM quiz ORDER BY date DESC") or die('Error');
$c=1;
while($row = mysqli_fetch_array($result)) {
	$title = $row['title'];
	$total = $row['total'];
	$sahi = $row['sahi'];
    $time = $row['time'];
	$eid = $row['eid'];
$q12=mysqli_query($con,"SELECT score FROM history WHERE eid='$eid' AND email='$email'" )or die('Error98');
$rowcount=mysqli_num_rows($q12);	
if($rowcount == 0){
	?><?php echo'
          <div class="row ">
            <div class="col-12 col-sm-12 col-lg-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Exam Of</h5>
                          <h2 class="mb-3 font-18">'.$title.'</h2>
                          <p class="mb-0"><a href="account.php?q=quiz&step=2&eid='.$eid.'&n=1&t='.$total.'"><span class="col-green">Click</span></a> and Play.</p>
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/3.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>';
		  ?>
         
		  <?php }
else
{
	?>
	<?php echo'          <div class="row ">
            <div class="col-12 col-sm-12 col-lg-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Exam Of</h5>
                          <h2 class="mb-3 font-18">'.$title.'</h2>
                          <p class="mb-0"><a href="update.php?q=quizre&step=25&eid='.$eid.'&n=1&t='.$total.'"><span class="col-red">Click</span></a> and Restart.</p>
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/3.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>';
		  ?>
		  	<?php
}
}
$c=0;

}?>
<?php
//ranking start
if(@$_GET['q']== 2) 
{
$q=mysqli_query($con,"SELECT * FROM rank  ORDER BY score DESC " )or die('Error223');
echo  '<div class="section-body">
 <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>Ranking</h4>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-striped" id="table-1">
<thead>
    <tr>
      <th scope="col">Rank</th>
      <th scope="col">Name</th>
      <th scope="col">Gender</th>
      <th scope="col">College</th>
	  <th scope="col">Score</th>
    </tr>
  </thead>';
$c=0;
while($row=mysqli_fetch_array($q) )
{
$e=$row['email'];
$s=$row['score'];
$q12=mysqli_query($con,"SELECT * FROM user WHERE email='$e' " )or die('Error231');
while($row=mysqli_fetch_array($q12) )
{
$name=$row['name'];
$gender=$row['gender'];
$college=$row['college'];
}
$c++;
echo '<tbody>
<tr>
      <th scope="row">'.$c.'</th>
      <td>'.$name.'</td>
      <td>'.$gender.'</td>
	  <td>'.$college.'</td>
      <td>'.$s.'</td>
    </tr>';
}
echo '</tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
			       </div>';}

?>
<!--Users-->
<?php if(@$_GET['q']==1) {

$result = mysqli_query($con,"SELECT * FROM user") or die('Error');
echo  '
<div class="section-body">
 <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>Users</h4>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-striped" id="table-1">
  <thead>
    <tr>
      <th scope="col">S.N</th>
      <th scope="col">Name</th>
      <th scope="col">Gender</th>
      <th scope="col">College</th>
	  <th scope="col">Email</th>
	  <th scope="col">Mobile</th>
	  <th scope="col">Password</th>
	  <th scope="col">Delete</th>
    </tr>
  </thead>';
  $c=1;
while($row = mysqli_fetch_array($result)) {
	$name = $row['name'];
	$mob = $row['mob'];
	$gender = $row['gender'];
    $email = $row['email'];
	$college = $row['college'];
	$password = $row['password'];
	echo '
	<tbody>
	<tr>
      <th scope="row">'.$c++.'</th>
      <td>'.$name.'</td>
      <td>'.$gender.'</td>
      <td>'.$college.'</td>
	  <td>'.$email.'</td>
	  <td>'.$mob.'</td>
	  <td>'.$password.'</td>
	  <td><a href="update.php?demail='.$email.'" class="btn btn-primary">Delete</a></td>
    </tr>';
	}
$c=0;
echo '
</tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
			       </div>';
}?>
			<!--User end-->
			<!--feedback start-->
<?php if(@$_GET['q']==3) {
$result = mysqli_query($con,"SELECT * FROM `feedback` ORDER BY `feedback`.`date` DESC") or die('Error');
echo  '<div class="section-body">
 <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>Feedback</h4>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-striped" id="table-1">
<thead>
    <tr>
      <th scope="col">S.N</th>
      <th scope="col">Subject</th>
      <th scope="col">Email</th>
      <th scope="col">Date</th>
	  <th scope="col">Time</th>
	  <th scope="col">By</th>
	  <th scope="col">Delete</th>
    </tr>
  </thead>';
$c=1;
while($row = mysqli_fetch_array($result)) {
	$date = $row['date'];
	$date= date("d-m-Y",strtotime($date));
	$time = $row['time'];
	$subject = $row['subject'];
	$name = $row['name'];
	$email = $row['email'];
	$id = $row['id'];
	echo '
	<tbody>
	<tr>
      <th scope="row">'.$c++.'</th>
      <td><a title="Click to open feedback" href="dash.php?q=3&fid='.$id.'">'.$subject.'</a></td>
      <td>'.$email.'</td>
      <td>'.$date.'</td>
	  <td>'.$time.'</td>
	  <td>'.$name.'</td>
	  <td><a href="update.php?fdid='.$id.'" class="btn btn-primary">Delete</a></td>
    </tr>';
}
echo '</tbody>
</table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
			       </div>';
}
?>
<!--feedback closed-->
<!--feedback reading portion start-->
<?php if(@$_GET['fid']) {
echo '<br />';
$id=@$_GET['fid'];
$result = mysqli_query($con,"SELECT * FROM feedback WHERE id='$id' ") or die('Error');
while($row = mysqli_fetch_array($result)) {
	$name = $row['name'];
	$subject = $row['subject'];
	$date = $row['date'];
	$date= date("d-m-Y",strtotime($date));
	$time = $row['time'];
	$feedback = $row['feedback'];
	
echo '<div class="section-body">
 <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>'.$subject.'</h4>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-striped" id="table-1">
<thead>
    <tr>
      <th scope="col">Subject</th>
      <th scope="col">Date</th>
	  <th scope="col">Time</th>
	  <th scope="col">Name</th>
	  <th scope="col">Feedback</th>
    </tr>
  </thead>';
echo'<tbody>
	<tr>
      <td>'.$subject.'</a></td>
      <td>'.$date.'</td>
	  <td>'.$time.'</td>
	  <td>'.$name.'</td>
	  <td>'.$feedback.'</td>
    </tr>';
}
echo '</tbody>
</table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
			       </div>';
}?>
<!--Feedback reading portion closed-->
<!-- Add Quiz -->
<?php
if(@$_GET['q']==4 && !(@$_GET['step']) ) {
echo'
  <div class="col-12 col-sm-12 col-lg-12">
                <div class="card">
                  <div class="boxs mail_listing">
                    <div class="inbox-center table-responsive">
                      <table class="table table-hover">
                        <thead>
                          <tr>
                            <th colspan="1">
                              <div class="inbox-header">
                                Add Quiz
                              </div>
                            </th>
                          </tr>
                        </thead>
                      </table>
                    </div>
                    <div class="row">
                      <div class="col-lg-12">
                        <form class="composeForm" name="form" action="update.php?q=addquiz"  method="POST">
                          <div class="form-group">
                            <div class="form-line">
                              <input type="text" id="name" name="name" class="form-control" placeholder="Enter Quiz Title" required>
                            </div>
                          </div>
                          <div class="form-group">
                            <div class="form-line">
                              <input type="number" id="total" name="total" class="form-control" placeholder="Enter total number of questions" min="1" required>
                            </div>
                          </div>
						  <div class="form-group">
                            <div class="form-line">
                              <input type="number" id="right" name="right" class="form-control" placeholder="Enter marks on right answer" min="0" type="number" required>
                            </div>
                          </div>
						  <div class="form-group">
                            <div class="form-line">
                              <input type="number" id="wrong" name="wrong" class="form-control" placeholder="Enter minus marks on wrong answer without sign" min="0" type="number" required>
                            </div>
                          </div>
						  <div class="form-group">
                            <div class="form-line">
                              <input type="number" id="time" name="time" class="form-control" placeholder="Enter time limit for test in minut (Mark Apply on an one Question)" min="1" type="number" required>
                            </div>
                          </div>
						  <div class="form-group">
                            <div class="form-line">
                              <input type="text" id="tag" name="tag" class="form-control" placeholder="Enter #tag which is used for searching" required>
                            </div>
                          </div>
						  <div class="form-group">
                            <div class="form-line">
                              <textarea rows="8" cols="8" name="desc" class="form-control" placeholder="Write description here..." required></textarea>  
                            </div>
                          </div>
                        
                      </div>
                      <div class="col-lg-12">
                        <div class="m-l-25 m-b-20">
                          <button type="submit" class="btn btn-info btn-border-radius waves-effect">Submit</button>
                        </div>
                      </div>
					  </form>
                    </div>
                  </div>
                </div>
			
              </div>';
				  }
?>
<!--add quiz end-->
<?php
if(@$_GET['q']==4 && (@$_GET['step'])==2 ) {
echo '
  <div class="col-12 col-sm-12 col-lg-12">
                <div class="card">
                  <div class="boxs mail_listing">
                    <div class="inbox-center table-responsive">
                      <table class="table table-hover">
                        <thead>
                          <tr>
                            <th colspan="1">
                              <div class="inbox-header">
                                Enter Question Details
                              </div>
                            </th>
                          </tr>
                        </thead>
                      </table>
                    </div>
                    <div class="row">
                      <div class="col-lg-12">
                        <form class="composeForm" name="form" action="update.php?q=addqns&n='.@$_GET['n'].'&eid='.@$_GET['eid'].'&ch=4 "  method="POST">
						<fieldset>
						';
						for($i=1;$i<=@$_GET['n'];$i++)
 {
echo '
<div class="form-group">
  <div class="form-line">
  <label for="email"><b>Question Number '.$i.'</b></label>
  <textarea rows="3" cols="5" name="qns'.$i.'" class="form-control" placeholder="Write question number '.$i.' here..."></textarea>  
  </div>
</div>
<!-- Text input-->
<div class="form-group">
  <label class="control-label" for="'.$i.'1"></label>  
  <div class="form-line">
  <input id="'.$i.'1" name="'.$i.'1" placeholder="Enter option a" class="form-control input-md" type="text">
    
  </div>
</div>
<!-- Text input-->
<div class="form-group">
  <label class="control-label" for="'.$i.'2"></label>  
  <div class="form-line">
  <input id="'.$i.'2" name="'.$i.'2" placeholder="Enter option b" class="form-control input-md" type="text">
    
  </div>
</div>
<!-- Text input-->
<div class="form-group">
  <label class="control-label" for="'.$i.'3"></label>  
  <div class="form-line">
  <input id="'.$i.'3" name="'.$i.'3" placeholder="Enter option c" class="form-control input-md" type="text">
    
  </div>
</div>
<!-- Text input-->
<div class="form-group">
  <label class="control-label" for="'.$i.'4"></label>  
  <div class="form-line">
  <input id="'.$i.'4" name="'.$i.'4" placeholder="Enter option d" class="form-control input-md" type="text">
    
  </div>
</div>
<label class="control-label"><b>Correct answer</b></label>
<select id="ans'.$i.'" name="ans'.$i.'" placeholder="Choose correct answer " class="form-control input-md" >
   <option value="a">Select answer for question '.$i.'</option>
  <option value="a">option a</option>
  <option value="b">option b</option>
  <option value="c">option c</option>
  <option value="d">option d</option> </select><br /><br />'; 
 }
    
echo '<div class="form-line">
                        <div class="m-l-25 m-b-20">
                          <button type="submit" class="btn btn-info btn-border-radius waves-effect">Submit</button>
                        </div>
                      </div>
						</fieldset>
						  </form>
                    </div>
                  </div>
                </div>
			
              </div>';
			 }
?>
<!--add quiz step 2 end-->
<!--remove quiz-->
<?php if(@$_GET['q']==5) {

$result = mysqli_query($con,"SELECT * FROM quiz ORDER BY date DESC") or die('Error');
$c=1;
while($row = mysqli_fetch_array($result)) {
	$title = $row['title'];
	$total = $row['total'];
	$sahi = $row['sahi'];
    $time = $row['time'];
	$eid = $row['eid'];
  echo'
  <div class="row ">
            <div class="col-12 col-sm-12 col-lg-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Remove Of</h5>
                          <h2 class="mb-3 font-18">'.$title.' Exam</h2>
                          <p class="mb-0"><a href="update.php?q=rmquiz&eid='.$eid.'"><span class="col-green">Click</span></a> and Remove Quiz.</p>

                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/3.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>';
  
}
$c=0;
}
?>
<!--History-->
<?php if(@$_GET['q']==6) {

$result = mysqli_query($con,"SELECT * FROM quiz") or die('Error');
echo  '<div class="section-body">
 <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>History</h4>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-striped" id="table-1">
<thead>
    <tr>
	  <th scope="col">S.N</th>
      <th scope="col">Title</th>
      <th scope="col">Right</th>
      <th scope="col">Wrong</th>
      <th scope="col">Total</th>
	  <th scope="col">Time</th>
	  <th scope="col">Discription</th>
	  <th scope="col">Date</th>
    </tr>
  </thead>';
$c=1;
while($row = mysqli_fetch_array($result)) {
	$title = $row['title'];
	$Right= $row['sahi'];
	$Wrong = $row['wrong'];
	$Total = $row['total'];
	$Time = $row['time'];
	$Dis = $row['intro'];
	$Date = $row['date'];
	$id = $row['eid'];
	echo '
	<tbody>
	<tr>
      <th scope="row">'.$c++.'</th>
      <td><a title="Click to open feedback" href="dash.php?q=6&usid='.$id.'">'.$title.'</a></td>
      <td>'.$Right.'</td>
      <td>'.$Wrong.'</td>
	  <td>'.$Total.'</td>
	  <td>'.$Time.'</td>
	  <td>'.$Dis.'</td>
	  <td>'.$Date.'</td>
    </tr>';
}
echo '</tbody>
</table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
			       </div>';
}
?>
<!--History closed-->
<!--History reading portion start-->
<?php if(@$_GET['usid']) {
$id=@$_GET['usid'];
		$c=0;
$result = mysqli_query($con,"SELECT * FROM history WHERE eid='$id' ") or die('Error');
echo 
 '<div class="card">
<div class="card-header">
                    <h4>Users</h4>
                  </div>
				  <div class="card-body">
<table class="table" >
<thead>
    <tr>
	<th scope="col">S.N</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
	  <th scope="col">Score</th>
	  <th scope="col">Level</th>
	  <th scope="col">Right</th>
	  <th scope="col">Wrong</th>
	  <th scope="col">Date</th>
    </tr>
  </thead>';
while($row = mysqli_fetch_array($result)) {
	$email = $row['email'];
	$score = $row['score'];
	$level= $row['level'];
	$right = $row['sahi'];
	$wrong	= $row['wrong'];
	$date =   $row['date'];
	
$q12=mysqli_query($con,"SELECT * FROM user WHERE email='$email'" )or die('Error231');
while($row=mysqli_fetch_array($q12) )
{
	$name = $row['name'];
}
$c++;
echo'<tbody>
	<tr>
	<td>'.$c.'</td>
      <td>'.$name.'</td>
      <td>'.$email.'</td>
	  <td>'.$score.'</td>
	  <td>'.$level.'</td>
	  <td>'.$right.'</td>
	  <td>'.$wrong.'</td>
	  <td>'.$date.'</td>
    </tr>';

}
echo '</tbody>
</table>
              </div>
            </div>';
}?>
<!--History reading portion closed-->
<?php if(@$_GET['q']==7) {
		if(isset($_POST['sub']))
{
$name = $_POST['Name'];
$instruction = $_POST['message'];
$date=date("Y-m-d");
$res=mysqli_query($con,"INSERT INTO instruction (Name,instruction,date) VALUES  ('$name' , '$instruction', '$date')")or die ("Error");
	if($res>0)
	{
		echo '<div class="alert alert-success alert-dismissible show fade">
                      <div class="alert-body">
                        <button class="close" data-dismiss="alert">
                          <span>&times;</span>
                        </button>
                        Send Successfully...
                      </div>
                    </div>';
	}
  else{
			echo '<div class="alert alert-danger alert-dismissible show fade">
                      <div class="alert-body">
                        <button class="close" data-dismiss="alert">
                          <span>&times;</span>
                        </button>
                        Sending Error...
                      </div>
                    </div>';
	}
}
	?>
  <div class="col-12 col-sm-12 col-lg-12">
                <div class="card">
                  <form method="POST" action="">
                    <div class="card-header">
                      <h4>Instruction</h4>
                    </div>
                    <div class="card-body">
					<div class="form-group">
                        <label>Your Name</label>
                        <input type="text" name="Name" class="form-control" required="Name" value="<?php echo $name;?>">
                      </div>
                      <div class="form-group mb-0">
                        <label>Message</label>
                        <textarea name="message" class="form-control" required=""></textarea>
                      </div>
                    </div>
                    <div class="card-footer text-right">
                      <button class="btn btn-primary" type="submit" name="sub">Submit</button>
                    </div>
                  </form>
                </div>
              </div>
<?php
}
?>
<!--Delete Instruction start-->
<?php if(@$_GET['q']==8) {
$result = mysqli_query($con,"SELECT * FROM `instruction` ORDER BY `instruction`.`date` DESC") or die('Error');
echo  '<div class="section-body">
 <div class="row">
              <div class="col-12 col-sm-12 col-lg-12">
                <div class="card">
                  <div class="card-header">
                    <h4>Instructions</h4>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-striped" id="table-1">
<thead>
    <tr>
      <th scope="col">S.N</th>
	  <th scope="col">Name</th>
      <th scope="col">Message</th>
      <th scope="col">Date</th>
	  <th scope="col">Delete</th>
    </tr>
  </thead>';
$c=1;
while($row = mysqli_fetch_array($result)) {
	$date = $row['date'];
	$date= date("d-m-Y",strtotime($date));
	$message = $row['instruction'];
	$name = $row['Name'];
	$id = $row['ID'];
	echo '
	<tbody>
	<tr>
      <th scope="row">'.$c++.'</th>
      <td><a title="Click to Open Instruction" href="dash.php?q=8&fidi='.$id.'">'.$name.'</a></td>
      <td>'.$message.'</td>
      <td>'.$date.'</td>
	  <td><a href="update.php?di='.$id.'" class="btn btn-primary">Delete</a></td>
    </tr>';
}
echo '</tbody>
</table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
			       </div>';
}
?>
<!--Delete Instruction closed-->
<!-- Instruction reading portion start-->
<?php if(@$_GET['fidi']) {
echo '<br />';
$id=@$_GET['fidi'];
$result = mysqli_query($con,"SELECT * FROM instruction WHERE id='$id' ") or die('Error');
while($row = mysqli_fetch_array($result)) {
	$date = $row['date'];
	$date= date("d-m-Y",strtotime($date));
	$message = $row['instruction'];
	$name = $row['Name'];
	$id = $row['ID'];
	
echo '<div class="section-body">
 <div class="row">
              <div class="col-12 col-sm-12 col-lg-12">
                <div class="card">
                  <div class="card-header">
                    <h4>'.$name.'</h4>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-striped" id="table-1">
<thead>
    <tr>
      <th scope="col">ID</th>
	  <th scope="col">Name</th>
      <th scope="col">Message</th>
      <th scope="col">Date</th>
    </tr>
  </thead>';
echo'<tbody>
	<tr>
      <td>'.$id.'</a></td>
      <td>'.$name.'</td>
	  <td>'.$message.'</td>
	  <td>'.$date.'</td>
    </tr>';

echo '</tbody>
</table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
			       </div>';
}}?>
<!--Delete Instruction reading portion closed-->
        </section>
          <div class="settingSidebar">
          <a href="javascript:void(0)" class="settingPanelToggle"> <i class="fa fa-spin fa-cog"></i>
          </a>
          <div class="settingSidebar-body ps-container ps-theme-default">
            <div class=" fade show active">
              <div class="setting-panel-header">Setting Panel
              </div>
              <div class="p-15 border-bottom">
                <h6 class="font-medium m-b-10">Select Layout</h6>
                <div class="selectgroup layout-color w-50">
                  <label class="selectgroup-item">
                    <input type="radio" name="value" value="1" class="selectgroup-input-radio select-layout" checked>
                    <span class="selectgroup-button">Light</span>
                  </label>
                  <label class="selectgroup-item">
                    <input type="radio" name="value" value="2" class="selectgroup-input-radio select-layout">
                    <span class="selectgroup-button">Dark</span>
                  </label>
                </div>
              </div>
              <div class="p-15 border-bottom">
                <h6 class="font-medium m-b-10">Sidebar Color</h6>
                <div class="selectgroup selectgroup-pills sidebar-color">
                  <label class="selectgroup-item">
                    <input type="radio" name="icon-input" value="1" class="selectgroup-input select-sidebar">
                    <span class="selectgroup-button selectgroup-button-icon" data-toggle="tooltip"
                      data-original-title="Light Sidebar"><i class="fas fa-sun"></i></span>
                  </label>
                  <label class="selectgroup-item">
                    <input type="radio" name="icon-input" value="2" class="selectgroup-input select-sidebar" checked>
                    <span class="selectgroup-button selectgroup-button-icon" data-toggle="tooltip"
                      data-original-title="Dark Sidebar"><i class="fas fa-moon"></i></span>
                  </label>
                </div>
              </div>
              <div class="p-15 border-bottom">
                <h6 class="font-medium m-b-10">Color Theme</h6>
                <div class="theme-setting-options">
                  <ul class="choose-theme list-unstyled mb-0">
                    <li title="white" class="active">
                      <div class="white"></div>
                    </li>
                    <li title="cyan">
                      <div class="cyan"></div>
                    </li>
                    <li title="black">
                      <div class="black"></div>
                    </li>
                    <li title="purple">
                      <div class="purple"></div>
                    </li>
                    <li title="orange">
                      <div class="orange"></div>
                    </li>
                    <li title="green">
                      <div class="green"></div>
                    </li>
                    <li title="red">
                      <div class="red"></div>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="p-15 border-bottom">
                <div class="theme-setting-options">
                  <label class="m-b-0">
                    <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input"
                      id="mini_sidebar_setting">
                    <span class="custom-switch-indicator"></span>
                    <span class="control-label p-l-10">Mini Sidebar</span>
                  </label>
                </div>
              </div>
              <div class="p-15 border-bottom">
                <div class="theme-setting-options">
                  <label class="m-b-0">
                    <input type="checkbox" name="custom-switch-checkbox" class="custom-switch-input"
                      id="sticky_header_setting">
                    <span class="custom-switch-indicator"></span>
                    <span class="control-label p-l-10">Sticky Header</span>
                  </label>
                </div>
              </div>
              <div class="mt-4 mb-4 p-3 align-center rt-sidebar-last-ele">
                <a href="#" class="btn btn-icon icon-left btn-primary btn-restore-theme">
                  <i class="fas fa-undo"></i> Restore Default
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <footer class="main-footer">
        <div class="footer-left">
          Developed by AHMED RAZA
        </div>
        <div class="footer-right">
        </div>
      </footer>
    </div>
  </div>
  <!-- General JS Scripts -->
  <script src="assets/js/app.min.js"></script>
  <!-- JS Libraies -->
  <script src="assets/bundles/datatables/datatables.min.js"></script>
  <script src="assets/bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
  <script src="assets/bundles/jquery-ui/jquery-ui.min.js"></script>
  <!-- Page Specific JS File -->
  <script src="assets/js/page/datatables.js"></script>
  <!-- Template JS File -->
  <script src="assets/js/scripts.js"></script>
  <!-- Custom JS File -->
  <script src="assets/js/custom.js"></script>
    <script src="assets/bundles/sweetalert/sweetalert.min.js"></script>
  <!-- Page Specific JS File -->
  <script src="assets/js/page/sweetalert.js"></script>
</body>


<!-- index.html  21 Nov 2019 03:47:04 GMT -->
</html>